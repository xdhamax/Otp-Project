import React from 'react';

const Error = () => {
  return (
    <div>Oops!, So sorry.There is an Error</div>
  )
}

export default Error;